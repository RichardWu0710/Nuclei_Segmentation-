function f5 = Func_PlotIndex(bw,tempObj,gg)
% this function is for plotting the index number on individual nuclei


tempic1 = zeros(size(bw));
        for j = 1:length(tempObj(:,1))
            tempic1 = tempic1+tempObj{j,1};
        end
        f5 = figure (5);
            imshow(tempic1);
        s = regionprops(gg, 'Centroid');
        imshow(tempic1)
        hold on
        for k = 1:numel(s)
            c = s(k).Centroid;
            text(c(1), c(2), sprintf('%d', k-1), ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle');
        end
        hold off


end